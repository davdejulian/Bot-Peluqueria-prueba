export const N8N_ADD_TO_CALENDAR = process.env.N8N_ADD_TO_CALENDAR ?? ''
export const N8N_GET_FROM_CALENDAR = process.env.N8N_GET_FROM_CALENDAR ?? ''

export const CHATPDF_API = process.env.CHATPDF_API ?? ''
export const CHATPDF_KEY = process.env.CHATPDF_KEY ?? ''
export const CHATPDF_SRC = process.env.CHATPDF_SRC ?? ''

export const DURATION_MEET = process.env.DURATION_MEET ?? ''


